<?php 
error_reporting(-1);
ini_set('display_errors', 'On');
include 'vendor/autoload.php';

Database::init('localhost', 'QUIZ', 'root', '');