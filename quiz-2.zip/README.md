#QuizNorth
QuizNorth is a JS/Flask powered trivia Quiz with categories, leaderboards(coming soon)